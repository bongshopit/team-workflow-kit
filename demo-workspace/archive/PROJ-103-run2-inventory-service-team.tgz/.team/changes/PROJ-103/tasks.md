﻿# PROJ-103 tasks

- [x] 1. Add atomic reservation logic and validation for unknown SKUs, non-positive quantities, and insufficient stock in InventoryService (AC1)
- [x] 2. Add atomic release logic and validation for unknown SKUs in InventoryService (AC2)
- [x] 3. Update inventory-service docs/api.md and order-service contract docs to match reserve/release API semantics (AC1, AC2, AC3, AC4)
- [x] 4. Add regression tests for reserve and release success and failure scenarios from the story and test plan (AC1, AC2)
