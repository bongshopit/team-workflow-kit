# Audit: PROJ-103

Repos: inventory-service, order-service. Final state: review. Generated 2026-11-01 17:05 UTC.
From the first to the last team.mjs call: 7.1 min (of which 34 s waiting at Gate 1).
Credits: 17.71. LLM calls: 106. Tokens in 4,196,956, out 59,127.

## Signals

- inventory-service: dev (subagent) used 68% of the credits (10.05 of 14.707, 55 LLM calls).
- inventory-service: 10 tool calls failed.
- inventory-service: in approved, list_dir failed 5 times in a row.
- order-service: main chat used 55% of the credits (1.652 of 3.006, 9 LLM calls).
- order-service: reviewer (subagent) used 45% of the credits (1.354 of 3.006, 13 LLM calls).
- order-service: 11 tool calls failed.
- order-service: in approved, read_file failed 4 times in a row.
- 17 team.mjs calls exited non-zero.
- 4 file or folder tool calls used a path that did not exist or was a folder (main [orchestrator] read_file, main [orchestrator] list_dir).
- 2 script call(s) matched no terminal span, so some spans may be unassigned.

## Cost by role: inventory-service

| role | credits | share | LLM calls | tokens in | tokens out |
| --- | --- | --- | --- | --- | --- |
| dev (subagent) | 10.05 | 68% | 55 | 2,652,697 | 32,470 |
| main chat | 3.394 | 23% | 17 | 552,797 | 11,412 |
| reviewer (subagent) | 1.263 | 9% | 11 | 328,314 | 4,017 |
| helper | 0 | 0% | 1 | 267 | 7 |

## Cost by phase: inventory-service

| phase | time | credits | LLM calls | tool calls | failed | agents |
| --- | --- | --- | --- | --- | --- | --- |
| before init-change (explore) | 1.8 min | 2.495 | 14 | 17 | 2 | helper, main chat |
| explored | 1 s | 0 | 0 | 1 | 0 |  |
| proposed | 8 s | 0.181 | 1 | 3 | 0 | main chat |
| approved | 4.7 min | 9.44 | 51 | 55 | 8 | main chat, dev (subagent) |
| applying | 11 s | 0.373 | 2 | 2 | 0 | dev (subagent) |
| review | 1.6 min | 2.218 | 16 | 16 | 0 | dev (subagent), main chat, reviewer (subagent) |

## Cost by role: order-service

| role | credits | share | LLM calls | tokens in | tokens out |
| --- | --- | --- | --- | --- | --- |
| main chat | 1.652 | 55% | 9 | 377,789 | 7,212 |
| reviewer (subagent) | 1.354 | 45% | 13 | 285,092 | 4,009 |

## Cost by phase: order-service

| phase | time | credits | LLM calls | tool calls | failed | agents |
| --- | --- | --- | --- | --- | --- | --- |
| explored | 5 s | 0.234 | 1 | 0 | 0 | main chat |
| proposed | 18 s | 0.644 | 4 | 1 | 0 | main chat |
| approved | 6.2 min | 2.127 | 17 | 20 | 11 | main chat, reviewer (subagent) |

## Flow

| state | time in state |
| --- | --- |
| explored | 0 s |
| explored | 5 s |
| proposed | 0 s |
| proposed | 34 s |
| approved | 10 s |
| approved | 4.5 min |
| applying | 11 s |
| review | 1.6 min (until the last call) |

Rework rounds: 0.

## Skills

| skill | read by | evidence |
| --- | --- | --- |
| team-run | main [orchestrator] | hook read, step in call log |
| team-explore | main [orchestrator] | hook read, step in call log |
| team-propose | - | step in call log |
| team-test-plan | - | step in call log |
| team-apply | - | step in call log |
| team-review | - | step in call log |
| team-summary | ? | hook read |

## Failures

team.mjs calls:

- set-ready test_plan: exit 5, test plan is not ready: | - AC1 has no scenario (expected a line starting S1.1) | - AC2 has no scenario (expected a line starting S2.1)
- set-ready test_plan: exit 5, test plan is not ready: | - AC3 has no scenario (expected a line starting S3.1) | - AC4 has no scenario (expected a line starting S4.1)
- set-status review: exit 2, illegal transition approved -> review
- set-status apply: exit 2, illegal transition approved -> apply
- set-status applied: exit 2, illegal transition approved -> applied
- set-status review: exit 2, illegal transition approved -> review
- set-status ready: exit 2, illegal transition approved -> ready
- set-status done: exit 2, illegal transition approved -> done
- set-status blocked: exit 4, blocked needs --reason
- set-status approved: exit 2, illegal transition approved -> approved
- set-status validated: exit 2, illegal transition approved -> validated
- set-status in-progress: exit 2, illegal transition approved -> in-progress
- set-status in_progress: exit 2, illegal transition approved -> in_progress
- set-status applied-review: exit 2, illegal transition approved -> applied-review
- set-status apply-review: exit 2, illegal transition approved -> apply-review
- set-status reviewed: exit 2, illegal transition approved -> reviewed
- set-status review: exit 5, validation failed for review: | - no test command: set TEAM_TEST_CMD or pass --skip-tests

Tool calls:

| role | tool | error | count |
| --- | --- | --- | --- |
| dev | list_dir | Error | 5 |
| dev | read_file | Error | 3 |
| main [orchestrator] | read_file | Error | 2 |
| reviewer | read_file | Error | 6 |
| reviewer | list_dir | Error | 5 |

Paths that did not exist (seen by the hook):

| role | tool | kind | count |
| --- | --- | --- | --- |
| main [orchestrator] | read_file | missing | 2 |
| main [orchestrator] | list_dir | directory | 2 |

## Coverage

Spans in the window: 2480. Assigned to this ticket: 321. Calls matched to a terminal span: 35 of 37. Hook events: 94.
Credits come from Copilot's telemetry (`copilot_usage_nano_aiu` divided by 1e9). Spans are tied to the ticket by the time of its team.mjs calls.
