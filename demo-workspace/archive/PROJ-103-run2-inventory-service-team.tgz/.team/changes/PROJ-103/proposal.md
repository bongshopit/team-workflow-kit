﻿# PROJ-103 proposal

## Summary
Reserve stock during order creation and give it back on cancellation without allowing double-release or oversell races.

## Scope
### inventory-service
- Add atomic reserve logic with validation for unknown SKUs, non-positive quantities, and insufficient stock.
- Add atomic release logic for known SKUs while preserving the available-count invariant.
- Update the public inventory API contract and docs to describe reserve/release semantics.
- Add regression tests for success and failure paths.

### order-service
- Reserve inventory before the order is stored and reject oversell attempts with 409.
- Release inventory once on order cancellation and reject repeated cancellation without a second release.
- Align `InventoryClient` and contract docs with the inventory reserve/release APIs.
- Add regression tests covering success and failure flows.
