﻿Reviewer: reviewer agent
Compared: story PROJ-103 ACs vs proposal.md, tasks.md, test-plan.md, and the implemented inventory reserve/release flow in InventoryService.java and InventoryServiceTest.java.
Compared: inventory API contract docs in docs/api.md against the reserve/release behavior and the required HTTP error semantics.
AC1: covered by the reserve logic and regression tests for valid reservation, insufficient stock, unknown SKU, and non-positive quantities.
AC2: covered by the release logic and regression tests for valid release, unknown SKU, and non-positive quantities.
Conventions: ok
Findings: none
Result: pass
