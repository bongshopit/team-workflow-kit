﻿S1.1 Reserve 4 from 10 available leaves 6 available.
S1.2 Reserve 5 from 3 available fails with 409 and leaves available at 3.
S1.3 Reserve against an unknown SKU fails with 404.
S1.4 Reserve with quantity 0 or less fails with 400.
S2.1 Release 4 from 6 available leaves 10 available.
S2.2 Release against an unknown SKU fails with 404.
