﻿Repo: inventory-service
State: review
What changed:
- AC1: added atomic reserve logic for valid quantities, unknown SKUs, and insufficient stock edge cases while preserving the available count invariant.
- AC2: added atomic release logic for known SKUs and kept the API contract aligned with the service behavior.
- Docs: updated the inventory API contract in docs/api.md to describe reserve and release operations and error codes.
Tasks ticked:
- [x] 1. Add atomic reservation logic and validation for unknown SKUs, non-positive quantities, and insufficient stock in InventoryService (AC1)
- [x] 2. Add atomic release logic and validation for unknown SKUs in InventoryService (AC2)
- [x] 3. Update inventory-service/docs/api.md and the contract usage in order-service to match the reserve/release API (AC1, AC2, AC3, AC4)
- [x] 4. Add regression tests for reserve and release success and failure scenarios from the story and test plan (AC1, AC2)
Test result: mvn test (BUILD SUCCESS, 13 tests, 0 failures, 0 errors)
Review result: pass
Merge order: inventory-service before order-service
Audit: PROJ-103-audit.md
Gate 2: waiting for human
