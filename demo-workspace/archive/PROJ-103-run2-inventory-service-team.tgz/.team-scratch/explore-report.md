﻿Story check: AC1 and AC2 are present with scenarios S1.1-S1.4 and S2.1-S2.2; no gaps found.

Impact:
- inventory-service: the stock ledger and stock-mutating methods in the service implementation need atomic reserve/release logic.
- inventory-service/docs/api.md: the public contract must describe reserve/release operations and error codes.
- order-service: InventoryClient and order creation/cancellation flows must call the new reserve/release contract.

Risk:
- Overselling can occur if reserve and release operations are not atomic or if cancellation releases inventory more than once.
- Contract drift between inventory-service and order-service may leave API calls mismatched.

Open questions: none.

Context used:
- demo-workspace/stories/PROJ-103.md
- demo-workspace/repos/inventory-service/README.md
- demo-workspace/repos/inventory-service/docs/api.md
- demo-workspace/repos/order-service/README.md
