﻿# PROJ-103 proposal

## Summary
Prevent overselling by reserving stock at placement and releasing it exactly once when an order is cancelled.

## Scope
- Reserve stock before persisting a new order and reject insufficient-stock requests without creating an order.
- Release stock once for open orders and reject second cancellation attempts before any additional side effects.
- Keep `InventoryClient` aligned with inventory-service API contracts and request/response semantics.
- Add regression coverage for create and cancel success and failure flows.
