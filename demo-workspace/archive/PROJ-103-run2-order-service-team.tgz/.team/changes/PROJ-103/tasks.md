﻿# PROJ-103 tasks

- [x] 1. Reserve inventory during order creation and reject insufficient stock without storing a conflicting order (AC3)
- [x] 2. Release inventory once on cancellation and reject repeated cancellation without extra release side effects (AC4)
- [x] 3. Align InventoryClient and service contract docs with the upstream inventory API and request/response details (AC1, AC2, AC3, AC4)
- [x] 4. Add regression tests covering create/cancel success and failure flows from the story and test plan (AC3, AC4)
