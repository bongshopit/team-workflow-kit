﻿S3.1 Create an order for 2 when inventory has enough stock and verify 2 are reserved.
S3.2 Create an order that exceeds available inventory fails with 409 and leaves no stored order.
S4.1 Cancel an open order for 2 and verify 2 are released in inventory.
S4.2 Cancel an already-cancelled order fails with 409 and releases nothing more.
