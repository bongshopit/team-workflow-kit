﻿Story check: AC3 and AC4 are present with scenarios S3.1-S3.2 and S4.1-S4.2; no gaps found.

Impact:
- order-service: create/cancel order flows must reserve stock on creation and release stock exactly once on cancellation.
- order-service/src: order service and InventoryClient code paths are implicated.
- docs/contracts/inventory.md: contract alignment with inventory-service reserve/release semantics.

Risk:
- A failure to reserve inventory before storing an order can result in overselling.
- A second cancellation can release inventory twice unless the order state is checked first.

Open questions: none.

Context used:
- demo-workspace/stories/PROJ-103.md
- demo-workspace/repos/order-service/README.md
- demo-workspace/repos/inventory-service/docs/api.md
- demo-workspace/repos/order-service/docs/contracts/inventory.md
